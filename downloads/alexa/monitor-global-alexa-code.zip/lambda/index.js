'use strict';
// Alexa-hosted Node.js; Amazon validates the request before invoking the Lambda.
// No shared secret, Alexa password, or device credential in public GitHub.
const Alexa=require('ask-sdk');
const AWS=require('aws-sdk');
const https=require('https');
const {DynamoDbPersistenceAdapter}=require('ask-sdk-dynamodb-persistence-adapter');
const {commandForIntent,normalizePairCode}=require('./commands');
const API='https://black-sky-9ba0.terrestre.workers.dev/alexa/v1';
const adapter=new DynamoDbPersistenceAdapter({
 tableName:process.env.DYNAMODB_PERSISTENCE_TABLE_NAME,
 createTable:false,
 dynamoDBClient:new AWS.DynamoDB({apiVersion:'latest',region:process.env.DYNAMODB_PERSISTENCE_REGION})
});
const response=(input,spoken,keep=false)=>{const b=input.responseBuilder.speak(spoken);if(keep)b.reprompt('Pode dizer Brent, temperatura, último sismo, sismo no Brasil, último resumo ou maiores do dia.');return b.withShouldEndSession(!keep).getResponse();};
const isIntent=(h,name)=>Alexa.getRequestType(h.requestEnvelope)==='IntentRequest'&&Alexa.getIntentName(h.requestEnvelope)===name;
// Alexa-hosted Node.js can still use Node 16. Do not rely on global fetch().
function callBridge(path,body,token=''){
 return new Promise((resolve,reject)=>{
  const payload=JSON.stringify(body);
  const url=new URL(API+path);
  const headers={'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)};
  if(token)headers.Authorization='Bearer '+token;
  const req=https.request(url,{method:'POST',headers,timeout:3800},res=>{
   if(res.statusCode>=300&&res.statusCode<400){res.resume();reject(new Error('redirect refused'));return;}
   const chunks=[];let size=0;
   res.on('data',chunk=>{
    size+=chunk.length;
    if(size>4096){req.destroy(new Error('response too large'));return;}
    chunks.push(chunk);
   });
   res.on('end',()=>{
    try{
     const data=JSON.parse(Buffer.concat(chunks).toString('utf8'));
     resolve({ok:res.statusCode>=200&&res.statusCode<300,status:res.statusCode,data});
    }catch{resolve({ok:false,status:res.statusCode,data:{}});}
   });
  });
  req.on('timeout',()=>req.destroy(new Error('request timed out')));
  req.on('error',reject);
  req.end(payload);
 });
}
const Launch={
 canHandle:h=>Alexa.getRequestType(h.requestEnvelope)==='LaunchRequest',
 async handle(h){
  const p=await h.attributesManager.getPersistentAttributes()||{};
  return response(h,p.skillToken?'Monitor Global pronto. Diga mostrar Brent, temperatura, último sismo, sismo no Brasil, último resumo ou maiores do dia.':'Bem-vindo ao Monitor Global. Na televisão, abra o aplicativo e escolha Vincular Alexa. Depois diga vincular código e os seis números mostrados na TV.',true);
 }
};
const Link={
 canHandle:h=>isIntent(h,'LinkIntent'),
 async handle(h){
  const slot=Alexa.getSlotValue(h.requestEnvelope,'codigo'),code=normalizePairCode(slot);
  if(!code)return response(h,'Não entendi os seis dígitos. Diga vincular código e os números mostrados na televisão.',true);
  try{
   const result=await callBridge('/link',{code});
   if(!result.ok){
    if(result.status===429)return response(h,'Foram feitas muitas tentativas. Tente novamente mais tarde.');
    if(result.status===404||result.status===400)return response(h,'Esse código não foi encontrado ou expirou. Peça um novo código na TV e tente novamente.',true);
    return response(h,'A ligação com o Monitor Global está temporariamente indisponível. Tente novamente.',true);
   }
   if(!/^[a-f0-9]{64}$/.test(result.data.skillToken||''))throw Error('invalid link');
   const persistent=await h.attributesManager.getPersistentAttributes()||{};
   h.attributesManager.setPersistentAttributes({...persistent,skillToken:result.data.skillToken});
   await h.attributesManager.savePersistentAttributes();
   return response(h,'Pronto, o Monitor Global está vinculado à sua Alexa! Você já pode pedir Brent, temperatura, último sismo, sismo no Brasil, último resumo ou maiores do dia.');
  }catch{return response(h,'Não consegui concluir o vínculo com a televisão. Tente novamente.',true);}
 }
};
const Cards={
 canHandle:h=>Alexa.getRequestType(h.requestEnvelope)==='IntentRequest'&&Boolean(commandForIntent(Alexa.getIntentName(h.requestEnvelope))),
 async handle(h){
  const command=commandForIntent(Alexa.getIntentName(h.requestEnvelope));
  const persistent=await h.attributesManager.getPersistentAttributes();
  if(!/^[a-f0-9]{64}$/.test(persistent.skillToken||''))return response(h,'Primeiro vincule o Monitor Global à sua televisão. Abra o aplicativo na TV, escolha Vincular Alexa e diga vincular código seguido dos seis números.',true);
  try{
   const result=await callBridge('/command',{command},persistent.skillToken);
   if(result.ok&&result.data.accepted){
    const label=command==='brent'?'Brent':command==='weather'?'temperatura':command==='recent-quake'?'último sismo':command==='last-summary'?'último resumo diário':command==='today'?'maiores sismos de hoje':'sismos no Brasil';
    return response(h,'Pedido enviado para a TV consultar '+label+' na televisão.');
   }
   if(result.status===401)return response(h,'A ligação com a TV expirou. Vincule o Monitor Global novamente usando um novo código.');
   if(result.status===409)return response(h,'A televisão não está conectada ao Monitor Global agora. Ligue o monitoramento no aplicativo da TV e tente novamente.');
   if(result.status===429)return response(h,'Já recebi um comando. Tente novamente em alguns segundos.');
   return response(h,'Não foi possível enviar o comando. Tente novamente.');
  }catch{return response(h,'Não consegui comunicar com o Monitor Global neste momento. Tente novamente.');}
 }
};
const Help={
 canHandle:h=>isIntent(h,'AMAZON.HelpIntent')||isIntent(h,'AMAZON.FallbackIntent'),
 handle:h=>response(h,'Posso pedir à TV Brent, temperatura, último sismo, sismo no Brasil, último resumo ou maiores do dia. Para vincular, diga vincular código e os seis números mostrados no aplicativo.',true)
};
const Stop={
 canHandle:h=>isIntent(h,'AMAZON.StopIntent')||isIntent(h,'AMAZON.CancelIntent'),
 handle:h=>response(h,'Até logo!')
};
const End={
 canHandle:h=>Alexa.getRequestType(h.requestEnvelope)==='SessionEndedRequest',
 handle:h=>h.responseBuilder.getResponse()
};
exports.handler=Alexa.SkillBuilders.custom()
 .addRequestHandlers(Launch,Link,Cards,Help,Stop,End)
 .addErrorHandlers({canHandle:()=>true,handle:h=>response(h,'O Monitor Global não conseguiu concluir o pedido. Tente novamente.')})
 .withPersistenceAdapter(adapter)
 .lambda();

